<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <p>
        {{ $test_message }} <br />
        {{ $test_id }} <br />
        {{ $test_titulo }} <br />
    </p>
  </body>
</html>

<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <p>
        <?php echo e($test_message); ?> <br />
        <?php echo e($test_id); ?> <br />
        <?php echo e($test_titulo); ?> <br />
    </p>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\suragra\resources\views/mails/test.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title','Empresa index'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="col-lg-12">
    <div class="ibox float-e-margins">
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Nueva Empresa</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                    </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <?php echo Form::open(['route'=> 'empresa.store', 'method'=>'POST']); ?>

                        <div class="form-group">
                            <label for="user_rut" >Rut <strong>*</strong></label>
                            <?php echo Form::text('empresa_rut', null, ['placeholder'=>'Rut del usuario', 'class'=>'form-control col-sm-9 rut', 'required']); ?>

                        </div>

                        <div class="form-group">
                            <label for="empresa_nombre" >Nombre / Razón Social <strong>*</strong></label>
                            <?php echo Form::text('empresa_nombre', null, ['placeholder'=>'Nombre o Razón Social', 'class'=>'form-control col-sm-9', 'required']); ?>

                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="empresa_direccion" >Dirección <strong>*</strong></label>
                            <?php echo Form::text('empresa_direccion', null, ['placeholder'=>'Dirección', 'class'=>'form-control col-sm-9', 'required']); ?>

                        </div>

                        <div class="form-group">
                            <label for="empresa_telefono" >Teléfono </label>
                            <?php echo Form::text('empresa_telefono', null, ['placeholder'=>'Telefono', 'class'=>'form-control col-sm-9']); ?>

                        </div>
                    </div>
                </div>
<br />

                <div class="text-right pb-8">
                        <?php echo Form::submit('Registrar Empresa ', ['class' => 'btn btn-primary block full-width m-b']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                    <div class="text-center texto-leyenda">
                        <p><strong>*</strong> Campos obligatorios</p>
                    </div>

            </div>
        </div>
    </div>
</div>


<div class="col-lg-12">
    <div class="ibox float-e-margins">
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Listado de empresas</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                </div>
            </div>
            <div class="card-body">
            <!--   <div class="col-lg-12 pb-3 pt-2">
                        <a href="<?php echo e(route('empresa.create')); ?>" class = 'btn btn-primary'>Crear nueva Empresa</a>
                    </div>
            -->
                <div class="table-responsive">
                    <table class="table table-hover" id="empresaTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Empresa</th>
                                <th>Rut</th>
                                <th>Dirección</th>
                                <th>Teléfono</th>
                                <th>Acci&oacute;n</th>

                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $empresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><small><?php echo e($emp->empresa_nombre); ?></small></td>
                                <td><small><?php echo e($emp->empresa_rut); ?></small></td>
                                <td><small><?php echo e($emp->empresa_direccion); ?></small></td>
                                <td><small><?php echo e($emp->empresa_telefono); ?></small></td>
                                <td>
                                    <small>
                                        <a href="<?php echo e(route('empresa.edit', Crypt::encrypt($emp->empresa_id))); ?>" class="btn-empresa"  title="Editar"><i class="far fa-edit"></i></a>
                                    </small>
                                    <small>
                                            <a href = "<?php echo e(route('empresa.destroy', Crypt::encrypt($emp->empresa_id))); ?>" onclick="return confirm('¿Esta seguro que desea eliminar este elemento?')" class="btn-empresa"><i class="far fa-trash-alt"></i>
                                            </a>
                                    </small>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('local-scripts'); ?>
    <script type="text/javascript">
        $(document).ready( function () {
        $('#empresaTable').DataTable();
    })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suragra\resources\views/empresa/index.blade.php ENDPATH**/ ?>
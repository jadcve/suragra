
<?php $__env->startSection('title','cuenta index'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-lg-12">
        <div class="ibox float-e-margins">
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Nueva Cuenta</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo Form::open(['route'=> 'cuenta.store', 'method'=>'POST']); ?>

                            <div class="form-group" >
                                <label for="cuenta_banco" >Banco <strong>*</strong></label>
                                <?php echo Form::text('cuenta_banco', null, ['placeholder'=>'Banco', 'class'=>'form-control col-sm-9 rut', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="cuenta_tipo" >Tipo <strong>*</strong></label>
                                <?php echo Form::text('cuenta_tipo', null, ['placeholder'=>'Tipo de cuenta', 'class'=>'form-control col-sm-9', 'required']); ?>

                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="cuenta_numero" >Número  <strong>*</strong></label>
                                <?php echo Form::text('cuenta_numero', null, ['placeholder'=>'Número de cuenta', 'class'=>'form-control col-sm-9', 'required']); ?>

                            </div>
                        </div>

                    </div>

                    <div class="text-right pb-5">
                        <?php echo Form::submit('Registrar Cuenta', ['class' => 'btn btn-primary block full-width m-b']); ?>

                        <?php echo Form::close(); ?>

                    </div>

                    <div class="text-center texto-leyenda">
                        <p><strong>*</strong> Campos obligatorios</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="col-lg-12">
        <div class="ibox float-e-margins">
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">Listado de Cuentas</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                    </div>
                </div>
                <div class="card-body">
                <!--   <div class="col-lg-12 pb-3 pt-2">
                            <a href="<?php echo e(route('cuenta.create')); ?>" class = 'btn btn-primary'>Crear nuevo Cuenta</a>
                        </div>
                -->
                    <div class="table-responsive">
                        <table class="table table-hover" id="dataTableAusentismo" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Banco</th>
                                <th>Tipo de Cuenta</th>
                                <th>Número</th>
                                <th>Acci&oacute;n</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><small><?php echo e($cta->cuenta_banco); ?></small></td>
                                    <td><small><?php echo e($cta->cuenta_tipo); ?></small></td>
                                    <td><small><?php echo e($cta->cuenta_numero); ?></small></td>

                                    <td>
                                        <small>
                                            <a href="<?php echo e(route('cuenta.edit',  Crypt::encrypt($cta->cuenta_id))); ?>" class="btn-empresa"><i class="far fa-edit"></i></a>
                                        </small>
                                        <small>
                                            <a href = "<?php echo e(route('cuenta.destroy', Crypt::encrypt($cta->cuenta_id))); ?>" onclick="return confirm('¿Esta seguro que desea eliminar este elemento?')" class="btn-empresa"><i class="far fa-trash-alt"></i>
                                            </a>
                                        </small>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\suragra\resources\views/cuenta/index.blade.php ENDPATH**/ ?>
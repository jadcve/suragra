let alarmaSuragra = {
    init: function(){
        console.log('hola');

        $('#enviarAlarma').click(function(){
            alert(12345);

        });

    }
}
